//////+++++++++++++++++++++++++++++++++++++| LIBRARIES / HEADERS |+++++++++++++++++++++++++++++++++++++
//#include "device_config.h"
//#include <stdint.h>
//#include <math.h>
//#include <stdio.h>
//
////+++++++++++++++++++++++++++++++++++++| DIRECTIVES |+++++++++++++++++++++++++++++++++++++
//#define _XTAL_FREQ 8000000
//#define SWEEP_STEP 1000
//#define SWEEP_FREQ 20
//
////+++++++++++++++++++++++++++++++++++++| DATA TYPES |+++++++++++++++++++++++++++++++++++++
//enum por_ACDC {digital, analog};          // digital = 0, analog = 1
//enum por_dir{output, input};
//
//////+++++++++++++++++++++++++++++++++++++| ISRs |+++++++++++++++++++++++++++++++++++++
////// ISR for high priority
////void __interrupt ( high_priority ) high_isr( void );
////// ISR for low priority
////void __interrupt ( low_priority ) low_isr( void );
//
////+++++++++++++++++++++++++++++++++++++| FUNCTION DECLARATIONS |+++++++++++++++++++++++++++++++++++++
//void portsInit(void);
//uint8_t char_to_seg(uint8_t);
//void send_to_disp(uint32_t);
//char key_scanner(void);
//
////+++++++++++++++++++++++++++++++++++++| MAIN |+++++++++++++++++++++++++++++++++++++
//void main(void){
//    portsInit();
//    while(1){
//
//        char display = key_scanner();
//        //char display = 0x05;
//        //printf("%X", display);
//
//        static uint32_t num = 0x0A0B0C0D;
//
//        // num = and con 0x000F0F0F
//        // num = 0x000B0C0D * 256;
//
//        num = num * 256;
//
//        num = num | display;
//
//        send_to_disp(num);
//
//        __delay_ms(SWEEP_STEP);
//
//    }
//}
//
////+++++++++++++++++++++++++++++++++++++| FUNCTIONS |+++++++++++++++++++++++++++++++++++++
//void portsInit(void){
//    ANSELA = digital;   // Set port A as Digital for keypad driving
//    TRISA  = 0x0F;      // For Port A, set pins 4 to 7 as outputs (rows), and pins 0 to 3 as inputs (cols)
//    ANSELB = digital;   // Set port B as Digital for 7 segment cathode selection (only 4 pins used)
//    TRISB  = 0x00;      // For Port B, set pins as outputs for cathode selection
//    ANSELD = digital;   // Set port D as Digital for 7 segment anodes
//    TRISD  = 0x00;      // for Port D, set all pins as outputs for 7 segment anodes
//    OSCCON = 0b01110100;// Set the internal oscillator to 8MHz and stable
//
////    TRISAbits.TRISA0 = output;
////    TRISAbits.TRISA1 = output;
////    TRISAbits.TRISA2 = output;
////    TRISAbits.TRISA3 = output;
////    TRISAbits.TRISA4 = input;
////    TRISAbits.TRISA5 = input;
////    TRISAbits.TRISA6 = input;
////    TRISAbits.TRISA7 = input;
////
////    TRISBbits.TRISB0 = output;
////    TRISBbits.TRISB1 = output;
////    TRISBbits.TRISB2 = output;
////    TRISBbits.TRISB3 = output;
////    TRISBbits.TRISB4 = output;
////
////    TRISDbits.TRISD0 = input;
////    TRISDbits.TRISD1 = input;
////    TRISDbits.TRISD2 = input;
////    TRISDbits.TRISD3 = input;
////    TRISDbits.TRISD4 = input;
////    TRISDbits.TRISD5 = input;
////    TRISDbits.TRISD6 = input;
////    TRISDbits.TRISD7 = input;
//}
//
//void send_to_disp(uint32_t disp_word){
//    for (char i = 0; i < 4; i++){
//        int internal_sweep = (int) pow(2, i);
//        int sweep = 0x0F & ~internal_sweep;
//        LATB = (char) sweep;
//        uint8_t num_disp = 0x000000FF & (disp_word >> i*8);
//        LATD = char_to_seg(num_disp);
//        __delay_ms(SWEEP_STEP);
//    }
//}
//
//uint8_t char_to_seg(uint8_t num){
//    uint8_t segments;
//    switch(num){
//        case 0:  segments = 0b00111111; break;
//        case 1:  segments = 0b00000110; break;
//        case 2:  segments = 0b01011011; break;
//        case 3:  segments = 0b01001111; break;
//        case 4:  segments = 0b01100110; break;
//        case 5:  segments = 0b01101101; break;
//        case 6:  segments = 0b01111101; break;
//        case 7:  segments = 0b00000111; break;
//        case 8:  segments = 0b01111111; break;
//        case 9:  segments = 0b01100111; break;
//        case 10: segments = 0b01110111; break;
//        case 11: segments = 0b01111100; break;
//        case 12: segments = 0b01011000; break;
//        case 13: segments = 0b01011110; break;
//        case 14: segments = 0b01111001; break;
//        default: segments = 0b01110001; break;
//    }
//    return segments;
//}
//
//char key_scanner(){
//
////    char key_pressed = 0x00;
////
////    LATAbits.LA0 = 0;
////    LATAbits.LA1 = 1;
////    LATAbits.LA2 = 1;
////    LATAbits.LA3 = 1;
////    __delay_ms(SWEEP_STEP);
////    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x01;}
////    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x02;}
////    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x03;}
////    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x0A;}
////
////    LATAbits.LA0 = 1;
////    LATAbits.LA1 = 0;
////    LATAbits.LA2 = 1;
////    LATAbits.LA3 = 1;
////    __delay_ms(SWEEP_STEP);
////    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x04;}
////    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x05;}
////    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x06;}
////    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x0B;}
////
////    LATAbits.LA0 = 1;
////    LATAbits.LA1 = 1;
////    LATAbits.LA2 = 0;
////    LATAbits.LA3 = 1;
////    __delay_ms(SWEEP_STEP);
////    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x07;}
////    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x08;}
////    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x09;}
////    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x0C;}
////
////    LATAbits.LA0 = 1;
////    LATAbits.LA1 = 1;
////    LATAbits.LA2 = 1;
////    LATAbits.LA3 = 0;
////    __delay_ms(SWEEP_STEP);
////    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x0F;}
////    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x00;}
////    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x0E;}
////    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_STEP);key_pressed = 0x0D;}
//
//    LATAbits.LA0 = 0;
//    LATAbits.LA1 = 1;
//    LATAbits.LA2 = 1;
//    LATAbits.LA3 = 1;
//    __delay_ms(SWEEP_FREQ);
//    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_FREQ); return 1;}
//    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_FREQ); return 2;}
//    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_FREQ); return 3;}
//    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_FREQ); return 10;}
//    LATAbits.LA0 = 1;
//    LATAbits.LA1 = 0;
//    LATAbits.LA2 = 1;
//    LATAbits.LA3 = 1;
//    __delay_ms(SWEEP_FREQ);
//    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_FREQ); return 4;}
//    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_FREQ); return 5;}
//    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_FREQ); return 6;}
//    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_FREQ); return 11;}
//    LATAbits.LA0 = 1;
//    LATAbits.LA1 = 1;
//    LATAbits.LA2 = 0;
//    LATAbits.LA3 = 1;
//    __delay_ms(SWEEP_FREQ);
//    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_FREQ); return 7;}
//    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_FREQ); return 8;}
//    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_FREQ); return 9;}
//    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_FREQ); return 12;}
//    LATAbits.LA0 = 1;
//    LATAbits.LA1 = 1;
//    LATAbits.LA2 = 1;
//    LATAbits.LA3 = 0;
//    __delay_ms(SWEEP_FREQ);
//    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_FREQ); return 14;}
//    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_FREQ); return 0;}
//    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_FREQ); return 15;}
//    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_FREQ); return 13;}
//    else return 'x';
//
////
////
////    char var = PORTA; // 8 bits
////
////    switch(var){
////        case 01110111: key_pressed = 0x01; break;
////        case 01111011: key_pressed = 0x02; break;
////        case 01111101: key_pressed = 0x03; break;
////        case 01111110: key_pressed = 0x0A; break;
////        case 10110111: key_pressed = 0x04; break;
////        case 10111011: key_pressed = 0x05; break;
////        case 10111101: key_pressed = 0x06; break;
////        case 10111110: key_pressed = 0x0B; break;
////        case 11010111: key_pressed = 0x07; break;
////        case 11011011: key_pressed = 0x08; break;
////        case 11011101: key_pressed = 0x09; break;
////        case 11011110: key_pressed = 0x0C; break;
////        case 11100111: key_pressed = 0x0F; break;
////        case 11101011: key_pressed = 0x00; break;
////        case 11101101: key_pressed = 0x0E; break;
////        case 11101110: key_pressed = 0x0D; break;
////        default: key_pressed = 0x10; break;
////    }
//        //return key_pressed;
//}
//
//
//



////+++++++++++++++++++++++++++++++++++++| LIBRARIES / HEADERS |+++++++++++++++++++++++++++++++++++++
#include "device_config.h"
#include <stdint.h>
#include <math.h>
#include <stdio.h>

//+++++++++++++++++++++++++++++++++++++| DIRECTIVES |+++++++++++++++++++++++++++++++++++++
#define _XTAL_FREQ 8000000
#define SWEEP_FREQ 20
#define SWEEP_STEP 800

//+++++++++++++++++++++++++++++++++++++| DATA TYPES |+++++++++++++++++++++++++++++++++++++
enum por_ACDC {digital, analog};          // digital = 0, analog = 1
enum por_dir{output, input};

////+++++++++++++++++++++++++++++++++++++| ISRs |+++++++++++++++++++++++++++++++++++++
//// ISR for high priority
//void __interrupt ( high_priority ) high_isr( void );
//// ISR for low priority
//void __interrupt ( low_priority ) low_isr( void );

//+++++++++++++++++++++++++++++++++++++| FUNCTION DECLARATIONS |+++++++++++++++++++++++++++++++++++++
void portsInit(void);
uint8_t char_to_seg(uint8_t);
void send_to_disp(uint32_t);
char key_scanner(void);
//+++++++++++++++++++++++++++++++++++++| MAIN |+++++++++++++++++++++++++++++++++++++
void main(void){
    int num_to_disp = 0;
    portsInit();
    while(1){
        static uint32_t num = 0x0A0B0C0D;
        send_to_disp(num);
        __delay_ms(SWEEP_STEP);
        char key = key_scanner();
        num = num * 256;
        num = num | key;
    }
}

//+++++++++++++++++++++++++++++++++++++| FUNCTIONS |+++++++++++++++++++++++++++++++++++++
void portsInit(void){
    ANSELA = digital;   // Set port A as Digital for keypad driving
    TRISA  = 0xF0;      // For Port A, set pins 4 to 7 as inputs (columns), and pins 0 to 3 as outputs (rows)
    ANSELB = digital;   // Set port B as Digital for 7 segment cathode selection (only 4 pins used)
    TRISB  = 0x00;      // For Port B, set pins as outputs for cathode selection
    ANSELD = digital;   // Set port D as Digital for 7 segment anodes
    TRISD  = 0x00;      // for Port D, set all pins as outputs for 7 segment anodes
    OSCCON = 0x74;      // Set the internal oscillator to 8MHz and stable
}

//char key_scanner(void){
//    LATAbits.LA0 = 0;
//    LATAbits.LA1 = 1;
//    LATAbits.LA2 = 1;
//    LATAbits.LA3 = 1;
//    __delay_ms(SWEEP_FREQ);
//    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_FREQ); return 1;}
//    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_FREQ); return 2;}
//    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_FREQ); return 3;}
//    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_FREQ); return 10;}
//    LATAbits.LA0 = 1;
//    LATAbits.LA1 = 0;
//    LATAbits.LA2 = 1;
//    LATAbits.LA3 = 1;
//    __delay_ms(SWEEP_FREQ);
//    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_FREQ); return 4;}
//    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_FREQ); return 5;}
//    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_FREQ); return 6;}
//    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_FREQ); return 11;}
//    LATAbits.LA0 = 1;
//    LATAbits.LA1 = 1;
//    LATAbits.LA2 = 0;
//    LATAbits.LA3 = 1;
//    __delay_ms(SWEEP_FREQ);
//    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_FREQ); return 7;}
//    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_FREQ); return 8;}
//    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_FREQ); return 9;}
//    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_FREQ); return 12;}
//    LATAbits.LA0 = 1;
//    LATAbits.LA1 = 1;
//    LATAbits.LA2 = 1;
//    LATAbits.LA3 = 0;
//    __delay_ms(SWEEP_FREQ);
//    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_FREQ); return 14;}
//    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_FREQ); return 0;}
//    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_FREQ); return 15;}
//    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_FREQ); return 13;}
//    else return 0;
//}

char key_scanner(void){
    LATAbits.LA0 = 0;
    LATAbits.LA1 = 1;
    LATAbits.LA2 = 1;
    LATAbits.LA3 = 1;
    __delay_ms(SWEEP_FREQ);
    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_FREQ); return 0x01;}
    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_FREQ); return 0x02;}
    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_FREQ); return 0x03;}
    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_FREQ); return 0x0A;}
    LATAbits.LA0 = 1;
    LATAbits.LA1 = 0;
    LATAbits.LA2 = 1;
    LATAbits.LA3 = 1;
    __delay_ms(SWEEP_FREQ);
    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_FREQ); return 0x04;}
    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_FREQ); return 0x05;}
    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_FREQ); return 0x06;}
    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_FREQ); return 0x0B;}
    LATAbits.LA0 = 1;
    LATAbits.LA1 = 1;
    LATAbits.LA2 = 0;
    LATAbits.LA3 = 1;
    __delay_ms(SWEEP_FREQ);
    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_FREQ); return 0x07;}
    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_FREQ); return 0x08;}
    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_FREQ); return 0x09;}
    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_FREQ); return 0x0C;}
    LATAbits.LA0 = 1;
    LATAbits.LA1 = 1;
    LATAbits.LA2 = 1;
    LATAbits.LA3 = 0;
    __delay_ms(SWEEP_FREQ);
    if      (PORTAbits.RA4 == 0) {__delay_ms(SWEEP_FREQ); return 0x0E;}
    else if (PORTAbits.RA5 == 0) {__delay_ms(SWEEP_FREQ); return 0x00;}
    else if (PORTAbits.RA6 == 0) {__delay_ms(SWEEP_FREQ); return 0x0F;}
    else if (PORTAbits.RA7 == 0) {__delay_ms(SWEEP_FREQ); return 0x0D;}
    else return 0x00;
}

void send_to_disp(uint32_t disp_word){
    for (char i = 0; i < 4; i++){
        int internal_sweep = (int) pow(2, i);
        int sweep = 0x0F & ~internal_sweep;
        LATB = (char) sweep;
        uint8_t num_disp = 0x000000FF & (disp_word >> i*8);
        LATD = char_to_seg(num_disp);
        __delay_ms(SWEEP_STEP);
    }
}

uint8_t char_to_seg(uint8_t num){
    uint8_t segments;
    switch(num){
        case 0:  segments = 0b00111111; break;
        case 1:  segments = 0b00000110; break;
        case 2:  segments = 0b01011011; break;
        case 3:  segments = 0b01001111; break;
        case 4:  segments = 0b01100110; break;
        case 5:  segments = 0b01101101; break;
        case 6:  segments = 0b01111101; break;
        case 7:  segments = 0b00000111; break;
        case 8:  segments = 0b01111111; break;
        case 9:  segments = 0b01100111; break;
        case 10: segments = 0b01110111; break;
        case 11: segments = 0b01111100; break;
        case 12: segments = 0b01011000; break;
        case 13: segments = 0b01011110; break;
        case 14: segments = 0b01111001; break;
        default: segments = 0b01110001; break;
    }
    return segments;
}
